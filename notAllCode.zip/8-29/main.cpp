#include <iostream>
using namespace std;

void hanoiRecur(int numToMove, int startPos, int displacement) {
//    cout << "Move " << numToMove << " disks from position " << startPos+1
//         << " over by " << (displacement%2)+1 << endl; //For debugging
    if(numToMove > 1) hanoiRecur(numToMove-1, startPos, displacement+1);
    cout << "Move " << (startPos%3)+1 << " to " << 1+(startPos+1+(displacement%2))%3
         << endl;
    if(numToMove > 1) hanoiRecur(numToMove-1, startPos+numToMove, displacement+1);
    return;
}
int main() {
    int n =1;
    while (1){
        cout << "One positive integer please: " << endl;
        cin >> n;
        if(n <= 0) break;
        hanoiRecur(n,0,0);
    }
    return 0;
}
