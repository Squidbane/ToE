#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct JamesKellFraction {
  int num;
  int denom;
};
typedef struct JamesKellFraction MyFraction;

struct FractionBST {
  MyFraction data;
  struct FractionBST* left;
  struct FractionBST* right;
};
typedef struct FractionBST MyFractionBST;
typedef MyFractionBST* MyFractionBSTPtr;
typedef MyFractionBST* MyFractionBSTAddr;

void getSmallestFractionBSTJamesKell( MyFractionBSTAddr );

MyFractionBSTPtr createFractionNodeBSTJamesKell( MyFraction* );
void insertFractionBSTJamesKell( MyFractionBSTAddr, MyFractionBSTPtr* );
void addFractionBSTJamesKell( MyFractionBSTAddr, MyFractionBSTPtr );

void searchFractionBSTJamesKell( MyFraction*, MyFractionBSTPtr );

void removeFractionBSTJamesKell( MyFraction*, MyFractionBSTPtr* );
void remove2ChildFractionNodeJamesKell( MyFractionBSTPtr* );
void remove1ChildFractionNodeJamesKell( MyFractionBSTPtr* );
void removeFractionLeafJamesKell( MyFractionBSTPtr* );

void displayFractionInorderBSTJamesKell( MyFractionBSTPtr );

struct PointerStackFractionNode {
  MyFractionBSTPtr dataPtr;
  struct PointerStackFractionNode* next;
};
typedef struct PointerStackFractionNode* FractionBSTStackPtr;
typedef FractionBSTStackPtr* FractionPointerStack;

MyFractionBSTAddr topFractionJamesKell( FractionPointerStack );
int isEmptyFractionBSTJamesKell( FractionPointerStack );
void pushFractionJamesKell( MyFractionBSTPtr, FractionPointerStack );
void popFractionJamesKell( FractionPointerStack );

int compareFractionJamesKell( MyFraction, MyFraction );
void reduceFractionJamesKell( MyFraction* );

int main() {
  int option;
  MyFraction frTemp;
  MyFractionBSTPtr myBSTPtr;
  myBSTPtr = 0; // empty BST

  frTemp.num = 50;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 25;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 75;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 90;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 65;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 55;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 10;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 45;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 35; //The instructions say 3/15. But based on the node's placement in
                   //the tree, I'm guessing this is a typo.
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 95;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  frTemp.num = 80;
  frTemp.denom = 1;
  insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ), &myBSTPtr );

  do {
    printf( "\n*************************** MENU ******************************" );
    printf( "\n* (1) Insert a (Fraction) node to a BST; no duplicate allowed *" );
    printf( "\n* (2) Display Inorder                                         *" );
    printf( "\n* (3) Search for a given (Fraction) node                      *" );
    printf( "\n* (4) Remove a node                                           *" );
    printf( "\n* (5) Get & display the smallest node                         *" );
    printf( "\n* (6) Quit                                                    *" );
    printf( "\n***************************************************************\n" );

    printf( "\nEnter the option (1 thru 6) : " );
    scanf( "%d", &option );

    switch ( option ) {
      case 1:
        printf( "\n--Insert--" );
        printf( "\n\tPlease enter the numerator " );
        scanf( "%d", &( frTemp.num ) );
        printf( "\n\tPlease enter the denominator " );
        scanf( "%d", &( frTemp.denom ) );
        reduceFractionJamesKell( &frTemp );
        if ( frTemp.denom < 0 ) {
          frTemp.denom *= -1;
          frTemp.num *= -1;
        }
        printf( "\nAdding node with value: %d/%d ...\n", frTemp.num, frTemp.denom );
        insertFractionBSTJamesKell( createFractionNodeBSTJamesKell( &frTemp ),
                                    &myBSTPtr );
        break;
      case 2:
        displayFractionInorderBSTJamesKell( myBSTPtr );
        break;
      case 3:
        printf( "\n--Search--" );
        printf( "\n\tPlease enter the numerator " );
        scanf( "%d", &( frTemp.num ) );
        printf( "\n\tPlease enter the denominator " );
        scanf( "%d", &( frTemp.denom ) );
        reduceFractionJamesKell( &frTemp );
        if ( frTemp.denom < 0 ) {
          frTemp.denom *= -1;
          frTemp.num *= -1;
        }
        printf( "\nSearching for a node with value: %d/%d...\n", frTemp.num,
                frTemp.denom );
        searchFractionBSTJamesKell( &frTemp, myBSTPtr );
        break;
      case 4:
        printf( "\n--Remove Node--" );
        printf( "\n\tPlease enter the numerator " );
        scanf( "%d", &( frTemp.num ) );
        printf( "\n\tPlease enter the denominator " );
        scanf( "%d", &( frTemp.denom ) );
        reduceFractionJamesKell( &frTemp );
        if ( frTemp.denom < 0 ) {
          frTemp.denom *= -1;
          frTemp.num *= -1;
        }
        printf( "\nTrying to remove node with value: %d/%d...\n", frTemp.num,
                frTemp.denom );
        removeFractionBSTJamesKell( &frTemp, &myBSTPtr );
        break;
      case 5:
        getSmallestFractionBSTJamesKell( myBSTPtr );
        break;
      case 6:
        break;
      default:
        printf( "\nInvalid selection. Please enter an integer 1 thru 6\n");
        break;
     }
  } while ( option != 6 );
  return 0;
}

void searchFractionBSTJamesKell( MyFraction* tempFraction,
                                 MyFractionBSTPtr tempAddr ) {
  MyFractionBSTPtr parent = tempAddr;
  if ( compareFractionJamesKell( *tempFraction, tempAddr->data ) == 2 ) {
    printf( "\nThat node is the root of the tree.\n");
    return;
  }
  while ( 1 ) {
    switch ( compareFractionJamesKell( *tempFraction, tempAddr->data ) ) {
      case 2: //If nodes are equal, then:
        printf( "\nThat node exists. It's parent is: %d/%d\n", ( parent->data ).num,
               ( parent->data ).denom );
        return;
        break; // optional
      case 1: //If desired node is smaller than current node:
        if ( tempAddr->left == 0 ) {
          printf( "\nNode not found.\n");
          return;
        } else {
          parent = tempAddr;
          tempAddr = tempAddr->left;
        }
        break;
      case 0: //If desired node is larger:
        if ( tempAddr->right == 0 ) {
          printf( "\nNode not found.\n");
          return; //Mmmmmmm spaghetti
        } else {
          parent = tempAddr;
          tempAddr = tempAddr->right;
        }
        break;
    }
  }
}

void removeFractionBSTJamesKell( MyFraction* tempFraction,
                                 MyFractionBSTPtr* nodeLink ) {
  MyFractionBSTPtr tempAddr = *nodeLink;
  while ( 1 ) {
    switch ( compareFractionJamesKell( *tempFraction, tempAddr->data ) ) {
      case 2: //If nodes are equal, then:
        if ( ( tempAddr->left != 0 ) && ( tempAddr->right != 0 ) ) {
          remove2ChildFractionNodeJamesKell( nodeLink );
        } else if ( ( tempAddr->left != 0 ) || ( tempAddr->right != 0 ) ) {
          remove1ChildFractionNodeJamesKell( nodeLink );
        } else {
          removeFractionLeafJamesKell( nodeLink );
        }
        return;
        break; // This break is optional; I leave it in for good practice
      case 1: //If desired node is smaller than current node:
        if ( tempAddr->left == 0 ) {
          printf( "\nNode not found.\n");
          return;
        } else {
          nodeLink = &( tempAddr->left );
          tempAddr = tempAddr->left;
        }
        break;
      case 0: //If desired node is larger:
        if ( tempAddr->right == 0 ) {
          printf( "\nNode not found.\n");
          return;
        } else {
          nodeLink = &( tempAddr->right );
          tempAddr = tempAddr->right;
        }
        break;
    }
  }
}

void getSmallestFractionBSTJamesKell( MyFractionBSTAddr nodeAddr ) {
  while ( nodeAddr->left != 0 ) {
    nodeAddr = nodeAddr->left;
  }
  printf( "\nSmallest Fraction:");
  printf( "\n\tNumerator:   %d", ( nodeAddr->data ).num );
  printf( "\n\tDenominator: %d\n", ( nodeAddr->data ).denom );
  return;
}

MyFractionBSTAddr topFractionJamesKell( FractionPointerStack myStackAddr ) {
	return ( *myStackAddr )->dataPtr;
}

void insertFractionBSTJamesKell( MyFractionBSTAddr nodeAddr,
                                 MyFractionBSTPtr* treeAddr ) {
  if ( *treeAddr == 0) {
    *treeAddr = nodeAddr;
  } else if ( ( nodeAddr->data ).denom == 0 ) {
    printf( "\nThe fraction cannot be added.\nThe denominator cant be zero.\n");
  } else {
    addFractionBSTJamesKell( nodeAddr, *treeAddr );
  }
}

void addFractionBSTJamesKell( MyFractionBSTAddr nodeAddr,
                              MyFractionBSTPtr tempAddr ) {
  while ( 1 ) {
    switch ( compareFractionJamesKell( nodeAddr->data, tempAddr->data  ) ) {
      case 2: //If nodes are equal, then:
        printf( "\nError: Node not added." );
        printf( "\nThe value already exists in the tree.\n" );
        return;
        break;
      case 1: //If new node is smaller:
        if ( tempAddr->left == 0 ) {
          tempAddr->left = nodeAddr;
          return;
        } else {
          tempAddr = tempAddr->left;
        }
        break;
      case 0: //If new node is larger:
        if ( tempAddr->right == 0 ) {
          tempAddr->right = nodeAddr;
          return;
        } else {
          tempAddr = tempAddr->right;
        }
        break;
    }
  }
}

int compareFractionJamesKell( MyFraction frA, MyFraction frB ) {
  if ( frA.num * frB.denom == frA.denom * frB.num ) {
    return 2;
  } else {
    return ( frA.num * frB.denom < frA.denom * frB.num ? 1 : 0 );
  }
}

int isEmptyFractionBSTJamesKell( FractionPointerStack myStackAddr ) {
  return ( *myStackAddr == 0 ? 1 : 0 );
}

void pushFractionJamesKell( MyFractionBSTPtr myFractionAddr,
                           FractionPointerStack myStackAddr ) {
  FractionBSTStackPtr stackNodePtr;
  stackNodePtr = ( FractionBSTStackPtr ) malloc(
                                 sizeof( struct PointerStackFractionNode ) );

  stackNodePtr->dataPtr = myFractionAddr;
  stackNodePtr->next = 0;

  if ( isEmptyFractionBSTJamesKell( myStackAddr ) ) {
    *myStackAddr = stackNodePtr;
  } else {
    stackNodePtr->next = *myStackAddr;
    *myStackAddr = stackNodePtr;
  }
  return;
}

void popFractionJamesKell( FractionPointerStack myStackAddr ) {
  FractionBSTStackPtr tempPtr;

  if ( isEmptyFractionBSTJamesKell( myStackAddr ) == 0 ) {
    tempPtr = *myStackAddr;
    *myStackAddr = ( *myStackAddr )->next;
    free( tempPtr );
  }

  return;
}

void displayFractionInorderBSTJamesKell( MyFractionBSTPtr myTree ) {
  FractionPointerStack tempStack;
  tempStack = ( FractionBSTStackPtr* ) malloc( sizeof( FractionBSTStackPtr ) );
  *tempStack = 0;

  while ( ( myTree != 0 ) || ( !isEmptyFractionBSTJamesKell( tempStack ) ) ) {
    if ( myTree != 0 ) {
      pushFractionJamesKell( myTree, tempStack );
      myTree = myTree->left;
    } else {
      myTree = topFractionJamesKell( tempStack );
      popFractionJamesKell( tempStack );
	  printf( "\nFor current fraction --\n\tnum : %d\n\tdenom : %d\n",
		  myTree->data.num, myTree->data.denom );
      myTree = myTree->right;
    }
  }
  free( tempStack );
  return;
}

void remove2ChildFractionNodeJamesKell( MyFractionBSTPtr* treeAddr ) {
  MyFractionBSTPtr rightAddr;
  MyFractionBSTPtr leftAddr;

  rightAddr = ( *treeAddr )->right;
  leftAddr = ( *treeAddr )->left;

  free( *treeAddr );

  *treeAddr = rightAddr;

  while ( rightAddr->left != 0 ) {
    rightAddr = rightAddr->left;
  }
  rightAddr->left = leftAddr;
  return;
}

void remove1ChildFractionNodeJamesKell( MyFractionBSTPtr* treeAddr ) {
  MyFractionBSTPtr childAddr;
  if ( ( *treeAddr )->right == 0 ) {
    childAddr = ( *treeAddr )->left;
  } else {
    childAddr = ( *treeAddr )->right;
  }
  free( *treeAddr );
  *treeAddr = childAddr;
  return;
}

void removeFractionLeafJamesKell( MyFractionBSTPtr* treeAddr ) {
  free( *treeAddr );
  *treeAddr = 0;
  return;
}

MyFractionBSTPtr createFractionNodeBSTJamesKell( MyFraction* frac ) {
  MyFractionBSTPtr tempPtr;

  tempPtr = ( MyFractionBSTPtr ) malloc( sizeof( MyFractionBST ) );
  ( tempPtr->data ).num = frac->num;
  ( tempPtr->data ).denom = frac->denom;
  tempPtr->left = 0;
  tempPtr->right = 0;

  return tempPtr;
}

/*
The following function is extremely inelegant, and isn't fully optimized;
but it does work.
There are many alternative methods: I could have saved a lot of abs() function
calls if I had set the sign of the fraction to memory at the begining; and then
treated both numerator and denominator as positive throughout. And I could have
stored the "greatest possible common factor" to an int and then worked my way up
to it from 2 rather than down. That method uses 4 bytes more memory, but is much
faster in some situations. For example: 323/437, where the common factor is 19.
*/
void reduceFractionJamesKell( MyFraction* frac ) {
  int temp;
  if ( frac->num == frac->denom ) { //If num and denom are equal, set both to 1
    frac->num = 1;
    frac->denom = 1;
  } else if ( abs( frac->num ) > abs( frac->denom ) ) {
    if ( frac->num % frac->denom == 0 ) { //Denom is a factor of num
      frac->num = frac->num / frac->denom;
      frac->denom = 1;
    } else {
      temp = abs( frac->denom / 2 ); //Greatest possible common factor
    }
  } else { //Numerator less than denominator
    if ( frac->denom % frac->num == 0 ) {
      frac->denom = frac->denom / frac->num;
      frac->num = 1;
    } else {
      temp = abs( frac->num / 2 ); //Greatest possible common factor
    }
  }
  while( temp >= 2 ) {
    if ( ( frac->num % temp == 0 )&&( (frac->denom % temp == 0) ) ) {
      frac->num = frac->num / temp;
      frac->denom = frac->denom / temp;
      temp = abs( ( ( abs( frac->num ) > abs( frac->denom )
                     ) ? frac->denom : frac->num ) / 2 );
                     //Greatest possible common factor
    } else {
    temp--;
    }
  }
}
