//import java.util.*;
//
///**
// *
// */
//public class TagMaker {
//    private String name;
//    private String organization;
//
//    /**
//     * @return the name
//     */
//    public String getName() {
//        return name;
//    }
//
//    /**
//     * @param name the name to set
//     */
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    /**
//     * @return the organization
//     */
//    public String getOrganization() {
//        return organization;
//    }
//
//    /**
//     * @param organization the organization to set
//     */
//    public void setOrganization(String organization) {
//        this.organization = organization;
//    }
//
//    d = newTagMaker("John Smith,MCP");
//
//
//System.out.println(d);
//
//}
