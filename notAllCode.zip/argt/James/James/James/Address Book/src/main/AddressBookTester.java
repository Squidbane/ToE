package main;

import java.util.ArrayList;

/*A main tester class for the AddressBook.
 * @author James Kell
 */
public class AddressBookTester {

    public static void main(String[] args) {
        AddressBook a = new AddressBook();

        Person p = new Person("John","Doe");
        a.add (p);
        Person p2 = new Person("John","Lennon");
        a.add (p2);
        a.add ("Bob","Dole");
        a.add ("Tom","Johnson");
        a.remove(p2);
        ArrayList<Person> tempList = a.search("John");
        a.printList(tempList);
        ArrayList<Person> tempList2 = a.search(1002);
        a.printList(tempList2);
    }
}