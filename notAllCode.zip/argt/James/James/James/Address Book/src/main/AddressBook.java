package main;

import java.util.ArrayList;
/**This class creates an array list of person objects and provides methods to
 * add, remove and search for persons.
 *
 * @author James Kell
 */
public class AddressBook {

    ArrayList<Person> contactList;

    AddressBook (){
        contactList = new ArrayList<Person>();
    }
    /**Adds a predefined person to the contact list.
     */
    void add(Person p) {
        if(!contactList.contains(p)){
             contactList.add(p);
        }
    }
    /**Creates a person with a name defined by two arguements
     * and adds them to the contact list.
     */
    void add(String fName, String lName) {
        Person p = new Person(fName, lName);
        contactList.add(p);
    }
    /**Removes a predefined person.
     */
    void remove(Person p) {
        if(contactList.contains(p)){
            contactList.remove(p);
        }
    }

    /**Search by name. Returns an arrayList of persons with that
     * first or last name.(If no names are found
     * an empty list is returned.)
     */
    ArrayList<Person> search(String name) {
        ArrayList<Person> tempList = new ArrayList<Person>();
        int i = 0;
        int c = 0; //Count of Persons found.
        System.out.println("Searching for people named '" + name + "'");
        while (i < contactList.size()) {
            Person p= contactList.get(i);
            if ((p.getFirstName().contains(name))||(p.getLastName().contains(name))) {
                tempList.add(p);
                c++;
            }
            i++;
        }
        System.out.println(c + " people found:");
        return tempList;
    }

    /**Search by ID number. Returns an arrayList of persons with that ID.
     * (If this list has more than one person, some programmer has broken
     * the iD count system.)
     */
    ArrayList<Person> search(int eyeDee) {  //Rhymes with ID
        ArrayList<Person> tempList = new ArrayList<Person>();
        int i = 0;
        int c = 0; //Count of people found
        System.out.println("Searching for people with ID: '" + eyeDee + "'");
        while (i < contactList.size()) {
            Person p= contactList.get(i);
            if ((p.getID() == eyeDee)) {
                tempList.add(p);
                c++;
            }
            i++;
        }
        System.out.println(c + " people found:");
        return tempList;
    }

    /**A method for printing an array list.
     */
    void printList(ArrayList<Person> someList) {
        for(int i=0;i<someList.size();i++) {
            Person p = someList.get(i);
            System.out.print(p);
        }
    }
}