package main;

/**A main class to create and test Person objects.
 *
 * @author James Kell
 */
public class PersonTester {

    public static void main(String[] args) {
        Person p1 = new Person("Thomas","Jefferson");
        Person p2 = new Person("Alexander","Hamilton");
        System.out.println(p1.getFirstName() + " " + p1.getLastName());
        System.out.println(p1.getFullName());
        p1.printFirstName();
        p1.printLastName();
        System.out.println(p1.getID());
        p1.printiDNumber();
        System.out.print(p2);

    }
}
