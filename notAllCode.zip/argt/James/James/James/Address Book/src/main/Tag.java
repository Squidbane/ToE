package main;

/**A class describing Tag objects with name and organization attributes.
 *
 * @author James Kell
 */
public class Tag {


}
