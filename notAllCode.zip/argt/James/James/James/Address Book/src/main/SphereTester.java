
package main;

/*A main class to test the various abilities of the
 *Sphere class.
 */
public class SphereTester {

    public static void main(String[] args) {
        Sphere s = new Sphere();
        Sphere s2 = new Sphere(1.1, 2.0, 3.0, 4.0);
        s.setX(3.0);
        s.setY(4.0);
        s.setZ(5.0);
        s.setR(5.0);
        
        System.out.println("Properties of sphere 1:");
        System.out.println("x = " + s.getX());
        System.out.println("y = " + s.getY());
        System.out.println("z = " + s.getZ());
        System.out.println("radius = " + s.getR());
        System.out.println("volume = " + s.getVolume());
        System.out.println("surface area = "
                + s.getSurfaceArea());
        System.out.println("");
        System.out.print(s2);
    }
}