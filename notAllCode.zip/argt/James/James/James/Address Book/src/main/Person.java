package main;

/**This class creates "person" objects
 * with the following attributes:
 * First Name
 * Last Name
 * Identification Number
 *
 * @author James Kell
 * @version 0.1
 */
public class Person {

    String firstName;
    String lastName;
    int iDNumber; // IDentification Number
    static int iDCount = 1000;  //The first person will receive ID number 1001.

    Person(String firstN, String lastN) {
        firstName = firstN;
        lastName = lastN;
        iDNumber = iDCount++;
    }

    String getLastName () {
        return lastName;
    }

    String getFirstName () {
        return firstName;
    }

    String getFullName () {
        return firstName + " " + lastName;
    }

    int getID () {
        return iDNumber;
    }

    void printLastName () {
        System.out.println(lastName);
    }

    void printFirstName () {
        System.out.println(firstName);
    }
    void printiDNumber () {
        System.out.println(iDNumber);
    }
   @Override
   public String toString() {
       String s = "Person with:\n";
       s = s + "Full Name: " + getFullName() + "\n";
       s = s + "and ID number: " + iDNumber + "\n";
       s = s + "\n";
       return s;
   }
}
