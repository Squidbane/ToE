package main;

/**This class describes Sphere objects with
 * the following attributes:
 * x, y, and z coordinates for the sphere's center,
 * the radius of the sphere, and
 * calculated values for its volume and surface area.
 * It also provides accessor and mutator methods for
 * those private attributes.
 */
public class Sphere {
    private double x,y,z,r,v,sa;

    /**A default constructor.
     */
    Sphere() {
        x = 1;
        y = 1;
        z = 1;
        r = 1;
        v = (4*Math.PI*r*r*r/3); //equation for the volume
        sa = (4*Math.PI*r*r); //equation for surface area
    }

    /**A constructor with paramaters to accept argue-
     * ments definining the sphere's basic attributes.
     */
    Sphere(double xc, double yc, double zc, double rc) { 
        x = xc;  //c stands for center
        y = yc;
        z = zc;
        r = rc;
        v = (4*Math.PI*r*r*r/3);
        sa = (4*Math.PI*r*r);
    }
    /**A mutator method for x coordinate of the center.
     */
    void setX(double xc) {
        x = xc;
    }
    /**A mutator method for y coordinate of the center.
     */
    void setY(double yc) {
        y = yc;
    }
    /**A mutator method for z coordinate of the center.
     */
    void setZ(double zc) {
        z = zc;
    }
    /**A mutator method for radius of the sphere.
     */
    void setR(double rc) {
        r = rc;
    }
    /**An accessor method for x.
     */
    double getX() {
        return x;
    }
    /**An accessor method for y.
     */
    double getY() {
        return y;
    }
    /**An accessor method for z.
     */
    double getZ() {
        return z;
    }
    /**An accessor method for r.
     */
    double getR() {
        return r;
    }
    /**An accessor method for v.
     */
    double getVolume() {
        return v;
    }
    /**An accessor method for surface area.
     */
    double getSurfaceArea() {
        return sa;
    }
    @Override
    public String toString() {
        String s = "Properties of sphere 2: \n";
        s = s + "x coordinate of center= " + x + "\n";
        s = s + "y coordinate of center= " + y + "\n";
        s = s + "z coordinate of center= " + z + "\n";
        s = s + "radius = " + r + "\n";
        s = s + "volume = " + v + "\n";
        s = s + "surface area = " + sa + "\n";
        return s;
    }
}