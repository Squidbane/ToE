/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package main;

/**
 *
 * @author Student
 */
public class TagMaker {
    public static void main(String[] args) {
        String[] tag = {"###########" , "####2######" , "##########"};
        System.out.println(tag[1]);


        
        printBlankTag();
    }
    void printBlankTag() {
            System.out.println("cookie");
            return "cookie";
        }
}
