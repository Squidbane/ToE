package shapes;
/**A Circle object can be created with arguments
 * (x,y,z,radius) or (Point,radius).
 * @author James Kell
 */
public class Circle extends TwoDimensionalShape{
    float radius;
    Circle(float xIn,float yIn, float zIn, float rIn) {
        x=xIn; y=yIn; z=zIn; radius=rIn;
    }
    Circle(Point p, float rIn) {
        x=p.x; y=p.y; z=p.z; radius=rIn;
    }
    @Override
    void print() {
        super.print();
        System.out.println("Radius: "+radius);
        System.out.println("Area: "+(float)getArea());
    }
    double getArea() {
        return Math.PI*radius*radius;
    }
    @Override
    public String toString() {
        return (super.toString() + "Radius: "+radius+"\n"+
                "Area: "+(float)getArea()+"\n");
    }
}