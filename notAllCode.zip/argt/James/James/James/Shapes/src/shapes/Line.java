package shapes;
/**A Line object can be created from 2 Point objects or 6 coordinates.
 * Lines preserve their length and orientation even if they are moved.
 * @author James Kell
 */
public class Line extends OneDimensionalShape {
    float i, j, k;
    Line(Point start,Point finish) {
        x=start.x; y=start.y; z=start.z; //(x,y,z) is the line's address
        i = finish.x - start.x; //(i,j,k) is its orientation and length
        j = finish.y - start.y;
        k = finish.z - start.z;
    }
    Line(float startX,float startY,float startZ,
            float finishX,float finishY,float finishZ) {
        x=startX; y=startY; z=startZ;
        i = finishX - startX;
        j = finishY - startY;
        k = finishZ - startZ;
    }
    double getLength() {
        return Math.pow(Math.pow(i,2)+Math.pow(j,2)+Math.pow(k,2),0.5);
    }
    @Override
    void print() {
        System.out.println("\nObject #"+getID()+" is a Line of length " +
                (float)getLength() + " that goes from");
        System.out.println("("+x+","+y+","+z+") to ("
                +(x+i)+","+(y+j)+","+(z+k)+")");
    }
    @Override
    public String toString() {
        String s = "\nObject #"+getID()+" is a Line of length ";
        s = s + (float)getLength() + " that goes from\n";
        s = s + "("+x+","+y+","+z+") to ("+(x+i)+","+(y+j)+","+(z+k)+")\n";
        return s;
    }
}