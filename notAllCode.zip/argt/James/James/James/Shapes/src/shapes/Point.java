package shapes;
/**This class describes a point in 3D space.
 * The compiler provides code to initialize y and z to zero.
 * @author James Kell
 */
public class Point extends ZeroDimensionalShape {
    Point(float xIn, float yIn, float zIn) {
        x=xIn; y=yIn; z=zIn;
    }
    Point(float xIn, float yIn) {
        x=xIn; y=yIn;
    }
    Point(float xIn) {
        x=xIn;
    }
}