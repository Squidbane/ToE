package shapes;
/**This file contains the abstract classes from which the concrete
 * classes are derived.
 * @author James Kell
 */
abstract class Shape {
    static int iDCount = 1000;
    final int shapeID = iDCount++;
    float x,y,z; //Center of Circle&Sphere, starting point of Line
    int getID() {
        return shapeID;
    }
    void print() {
        System.out.print("\nObject #"+getID()+" has attributes:\n" +
                getClass()+"\n" +
                "location ("+x+","+y+","+z+")\n");
    }
    void move(float newX, float newY, float newZ) {
        x=newX; y=newY; z=newZ;
    }
    @Override
    public String toString() {
        return "\nObject #"+getID()+" has attributes:\n" +
                getClass()+"\n" +
                "location ("+x+","+y+","+z+")\n";
    }
}
abstract class ZeroDimensionalShape extends Shape {
    //Contains Point class.
}
abstract class OneDimensionalShape extends ZeroDimensionalShape {
    //Contains Line class.
}
abstract class TwoDimensionalShape extends OneDimensionalShape {
    abstract double getArea(); //For 3D shapes, this returns surface area.
}
abstract class ThreeDimensionalShape extends TwoDimensionalShape {
    abstract double getVolume();
}