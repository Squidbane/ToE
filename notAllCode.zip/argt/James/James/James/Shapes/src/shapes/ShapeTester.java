package shapes;
/**This main class creates an array of objects and moves each to (2,2,2)
 * All attributes other than address should be unaffected by the move.
 * @author James Kell
 */
public class ShapeTester {
    public static void main(String[] args) {
        System.out.println("Note: All coordinates are in format (x,y,z).");
        Shape[] s = new Shape[4];
        s[0] = new Point(1,1);
        s[1] = new Line(new Point(1,2,3), new Point(3,4,5));
        s[2] = new Circle(new Point(1,1,1),3);
        s[3] = new Sphere(1,2,1,4);

        for (int i=0; i< s.length; i++) {
            s[i].print();
            s[i].move(2,2,2);
            s[i].print();
        }
    }
}