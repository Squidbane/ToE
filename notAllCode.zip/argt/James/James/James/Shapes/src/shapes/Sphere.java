package shapes;
/**A Sphere object can be created with arguments
 * (x,y,z,radius) or (Point,radius).
 * @author James Kell
 */
public class Sphere extends ThreeDimensionalShape {
    float radius;
    Sphere(float xIn,float yIn,float zIn,float r) {
        x=xIn; y=yIn; z=zIn; radius=r;
    }
    Sphere(Point pIn, float r) {
        x=pIn.x; y=pIn.y; z=pIn.z; radius=r;
    }
    double getArea() {
        return 4*Math.PI*radius*radius;
    }
    double getVolume() {
        return (4.0/3)*radius*radius*radius*Math.PI;
    }
    @Override
    void print() {
        System.out.print(toString());
    }
    @Override
    public String toString() {
        return super.toString()+"Radius: "+radius+"\n"+
                "Surface Area: "+(float)getArea()+"\n"+
                "Volume: "+(float)getVolume()+"\n";
    }
}