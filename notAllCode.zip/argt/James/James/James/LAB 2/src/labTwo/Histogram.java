package labTwo;

/**A Histogram object is an array of counters to track the frequency of numbers
 * that fall within each of the equaly sized intervals within the specified
 * range.
 * @author James Kell
 */
public class Histogram {

    public int[] counters;
    int min, max;

    Histogram(int min, int max, int num) { //num is number of counters
        counters = new int[num];
        this.min = min;
        this.max = max;
    }
    Histogram(int min, int max) {
        
    }
    void add(double x) throws Exception{
        if((x > max)||(x < min)){
            throw new Exception("Out of Range " + x);
        }

    }
    void reset() {

    }
    void plotFrequency() {

    }
    void plotCumulative() {

    }
}
