package labTwo;

/**
 *
 * @author James Kell
 */
public class HistogramTester {
    public static void main(String[] args) {
        Histogram hist = new Histogram(0,1,7);
        try {
            hist.add(0.7);
        }
        catch(Exception e) {
            System.out.println(e.getMessage());
        }
        finally {
            int i = hist.min;
            System.out.println(i);
        }
    }
}