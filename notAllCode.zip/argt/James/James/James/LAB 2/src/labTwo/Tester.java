/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package labTwo;

/**
 *
 * @author Student
 */
public class Tester {
    public static void main(String[] args) {
            Deck d1=new Deck();
            Deck d2=new Deck();
            for(int i=0;i<30;i++) {
                d1.Shuffle();
                System.out.print(d1);
                if(d1.equals(d2)){
                    break;
                }
            }
        }
}