package javaapplication2;


public class MotorCycleTester {

    public static void main (String args[]) {
        Motorcycle m= new Motorcycle();
        m.make="Yamaha RZ350";
        m.color="yellow";
        System.out.println("Calling showAtts...");
        m.showAtts();
        System.out.println("_______");
        System.out.println("Starting engine...");
        m.startEngine();
        System.out.println("_______");
        System.out.println("Calling showAtts...");
        m.showAtts();
        System.out.println("_______");
        System.out.println("Starting engine...");
        m.startEngine();
    }
}