package maze;
import java.util.*;
import java.io.*;
/**
 *
 * @author James
 */
public class Maze {
File maze0 = new File("maze.txt");
Scanner scanguy = new Scanner(maze0);

}
