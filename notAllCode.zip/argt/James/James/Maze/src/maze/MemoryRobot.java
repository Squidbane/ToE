/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package maze;

/**
 *
 * @author Student
 */
public class MemoryRobot {

}
