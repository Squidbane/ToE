#include<stdio.h>
void ToH(int n2Mov,int orign,int dest){
	if(n2Mov>1)ToH(n2Mov-1,orign,3-orign-dest);
	printf("move %d to %d\n",orign+1,dest+1);
	if(n2Mov>1)ToH(n2Mov-1,3-orign-dest,dest);}
int main(int n,char**a){
	printf("One positive integer please: ");
	scanf("%d",&n);
	ToH(n,0,1);
	return 0;}
